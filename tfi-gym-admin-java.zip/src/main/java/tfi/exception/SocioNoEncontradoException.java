package tfi.exception;

public class SocioNoEncontradoException extends RuntimeException {
    public SocioNoEncontradoException(String msg){ super(msg); }
}
