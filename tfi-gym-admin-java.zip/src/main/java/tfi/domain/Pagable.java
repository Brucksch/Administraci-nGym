package tfi.domain;

@FunctionalInterface
public interface Pagable {
    double calcularCuota();
}
