package tfi.domain;

public enum Plan {
    BASICO(15000), FULL(22000), PREMIUM(30000);
    private final double precio;
    Plan(double p){ this.precio = p; }
    public double precio(){ return precio; }
}
