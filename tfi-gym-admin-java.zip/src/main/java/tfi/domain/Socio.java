package tfi.domain;

import java.time.LocalDate;
import java.time.Period;
import java.util.Objects;

public class Socio implements Identificable, Pagable {
    private final String dni; // clave lógica
    private String nombre;
    private Plan plan;
    private final LocalDate fechaAlta;

    public Socio(String dni, String nombre, Plan plan, LocalDate fechaAlta){
        this.dni = Objects.requireNonNull(dni);
        this.nombre = Objects.requireNonNull(nombre);
        this.plan = Objects.requireNonNull(plan);
        this.fechaAlta = fechaAlta == null ? LocalDate.now() : fechaAlta;
    }
    public String getDni(){ return dni; }
    public String getNombre(){ return nombre; }
    public void setNombre(String nombre){ this.nombre = Objects.requireNonNull(nombre); }
    public Plan getPlan(){ return plan; }
    public void setPlan(Plan plan){ this.plan = Objects.requireNonNull(plan); }
    public LocalDate getFechaAlta(){ return fechaAlta; }

    @Override public String id(){ return dni; }

    @Override public double calcularCuota(){
        long meses = Period.between(fechaAlta, LocalDate.now()).toTotalMonths();
        double base = plan.precio();
        return meses >= 12 ? base * 0.9 : base;
    }

    @Override public String toString(){
        return "Socio{dni='" + dni + ''' +
               ", nombre='" + nombre + ''' +
               ", plan=" + plan +
               ", alta=" + fechaAlta + '}';
    }

    @Override public boolean equals(Object o){
        if(this == o) return true;
        if(!(o instanceof Socio)) return false;
        Socio s = (Socio)o; return Objects.equals(dni, s.dni);
    }
    @Override public int hashCode(){ return Objects.hash(dni); }
}
