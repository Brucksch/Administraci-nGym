package tfi.domain;

@FunctionalInterface
public interface Identificable {
    String id();
}
