package tfi.service;

import tfi.domain.Plan;
import tfi.domain.Socio;
import tfi.exception.SocioNoEncontradoException;
import tfi.util.OperacionLog;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class GimnasioService {
    private final List<Socio> socios = new ArrayList<>();
    private final Map<String, Socio> indicePorDni = new HashMap<>();
    private final OperacionLog log = new OperacionLog();
    private final int[] altasPorMes = new int[12];

    public void altaSocio(Socio s){
        if(indicePorDni.containsKey(s.getDni())) throw new IllegalArgumentException("Ya existe DNI " + s.getDni());
        socios.add(s);
        indicePorDni.put(s.getDni(), s);
        LocalDate fa = s.getFechaAlta();
        altasPorMes[fa.getMonthValue()-1]++;
        log.push("ALTA socio " + s.getDni() + " (" + s.getNombre() + ") plan " + s.getPlan());
    }
    public Socio buscarPorDni(String dni){
        Socio s = indicePorDni.get(dni);
        if(s == null) throw new SocioNoEncontradoException("No se encontró socio con DNI " + dni);
        return s;
    }
    public void modificarNombre(String dni, String nuevoNombre){
        Socio s = buscarPorDni(dni); s.setNombre(nuevoNombre);
        log.push("MODIFICAR nombre de " + dni + " a '" + nuevoNombre + "'");
    }
    public void cambiarPlan(String dni, Plan nuevo){
        Socio s = buscarPorDni(dni); s.setPlan(nuevo);
        log.push("CAMBIAR plan de " + dni + " a " + nuevo);
    }
    public boolean bajaSocio(String dni){
        Socio s = indicePorDni.remove(dni);
        if(s == null) return false;
        boolean removed = socios.removeIf(x -> x.getDni().equals(dni));
        if(removed) log.push("BAJA socio " + dni);
        return removed;
    }
    public List<Socio> listarOrdenadosPorNombre(){
        return socios.stream()
                .sorted(Comparator.comparing(Socio::getNombre, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toUnmodifiableList());
    }
    public double cuotaDe(String dni){
        return buscarPorDni(dni).calcularCuota();
    }
    public int[] getAltasPorMes(){ return Arrays.copyOf(altasPorMes, altasPorMes.length); }
    public OperacionLog getLog(){ return log; }
    public boolean existeDni(String dni){ return indicePorDni.containsKey(dni); }
    public boolean hayConNombre(String patron){
        String p = patron.toLowerCase();
        return socios.stream().anyMatch(s -> s.getNombre().toLowerCase().contains(p));
    }
}
