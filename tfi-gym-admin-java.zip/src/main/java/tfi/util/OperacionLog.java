package tfi.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.function.Consumer;

/** Lista enlazada simple para bitácora de operaciones */
public class OperacionLog {
    static class Nodo {
        final LocalDateTime ts; final String msg; Nodo next;
        Nodo(LocalDateTime ts, String msg){ this.ts = ts; this.msg = msg; }
    }
    private Nodo head, tail; private int size = 0;

    public void push(String msg){
        Nodo n = new Nodo(LocalDateTime.now(), msg);
        if(head == null){ head = tail = n; } else { tail.next = n; tail = n; }
        size++;
    }
    public void forEach(Consumer<String> action){
        Nodo it = head; DateTimeFormatter f = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        while(it != null){ action.accept("[" + it.ts.format(f) + "] " + it.msg); it = it.next; }
    }
    public int size(){ return size; }
}
