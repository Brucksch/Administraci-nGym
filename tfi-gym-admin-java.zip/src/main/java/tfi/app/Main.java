package tfi.app;

import tfi.domain.*;
import tfi.service.GimnasioService;
import tfi.exception.SocioNoEncontradoException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);
    private static final DateTimeFormatter DF = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private static int leerEntero(String prompt){
        while(true){
            System.out.print(prompt);
            try { return Integer.parseInt(sc.nextLine().trim()); }
            catch(Exception e){ System.out.println("Ingrese un número válido."); }
        }
    }
    private static String leerTexto(String prompt){
        System.out.print(prompt); return sc.nextLine();
    }
    private static LocalDate leerFecha(String prompt){
        System.out.print(prompt);
        String s = sc.nextLine().trim();
        if(s.isEmpty()) return null;
        try { return LocalDate.parse(s, DF); }
        catch(Exception e){ System.out.println("Formato inválido, se usará hoy."); return null; }
    }
    private static Plan leerPlan(){
        System.out.println("Plan (1=BASICO, 2=FULL, 3=PREMIUM): ");
        int opt = leerEntero("> ");
        return switch (opt){
            case 1 -> Plan.BASICO;
            case 2 -> Plan.FULL;
            case 3 -> Plan.PREMIUM;
            default -> { System.out.println("Opción inválida, se usará BASICO."); yield Plan.BASICO; }
        };
    }
    private static void mostrarMenu(){
        System.out.println("\n===== ADMINISTRACIÓN DE GIMNASIO =====");
        System.out.println("1) Alta socio");
        System.out.println("2) Buscar socio por DNI");
        System.out.println("3) Modificar nombre de socio");
        System.out.println("4) Cambiar plan de socio");
        System.out.println("5) Baja socio");
        System.out.println("6) Listar socios (ordenados por nombre)");
        System.out.println("7) Calcular cuota de un socio");
        System.out.println("8) Ver altas por mes (array)");
        System.out.println("9) Ver bitácora (lista enlazada propia)");
        System.out.println("0) Salir");
    }

    public static void main(String[] args){
        GimnasioService srv = new GimnasioService();

        // semilla
        srv.altaSocio(new Socio("12345678", "Ana Pérez", Plan.BASICO, LocalDate.now().minusMonths(2)));
        srv.altaSocio(new Socio("23456789", "Juan Gómez", Plan.FULL, LocalDate.now().minusMonths(14)));
        srv.altaSocio(new Socio("34567890", "Bruno Díaz", Plan.PREMIUM, LocalDate.now()));

        int op;
        do{
            mostrarMenu();
            op = leerEntero("Opción: ");
            try{
                switch(op){
                    case 1 -> {
                        System.out.println("-- Alta de socio --");
                        String dni = leerTexto("DNI: ").trim();
                        if(srv.existeDni(dni)) throw new IllegalArgumentException("El DNI ya existe");
                        String nombre = leerTexto("Nombre y apellido: ");
                        Plan plan = leerPlan();
                        LocalDate alta = leerFecha("Fecha de alta (dd/MM/yyyy) [enter para hoy]: ");
                        if(alta == null) alta = LocalDate.now();
                        srv.altaSocio(new Socio(dni, nombre, plan, alta));
                        System.out.println("OK: socio dado de alta");
                    }
                    case 2 -> {
                        System.out.println("-- Buscar socio --");
                        String dni = leerTexto("DNI: ").trim();
                        System.out.println(srv.buscarPorDni(dni));
                    }
                    case 3 -> {
                        System.out.println("-- Modificar nombre --");
                        String dni = leerTexto("DNI: ").trim();
                        String nombre = leerTexto("Nuevo nombre: ");
                        srv.modificarNombre(dni, nombre);
                        System.out.println("OK: nombre actualizado");
                    }
                    case 4 -> {
                        System.out.println("-- Cambiar plan --");
                        String dni = leerTexto("DNI: ").trim();
                        Plan p = leerPlan();
                        srv.cambiarPlan(dni, p);
                        System.out.println("OK: plan actualizado");
                    }
                    case 5 -> {
                        System.out.println("-- Baja de socio --");
                        String dni = leerTexto("DNI: ").trim();
                        boolean ok = srv.bajaSocio(dni);
                        System.out.println(ok ? "OK: socio eliminado" : "No existía ese DNI");
                    }
                    case 6 -> {
                        System.out.println("-- Listado de socios --");
                        List<Socio> lista = srv.listarOrdenadosPorNombre();
                        if(lista.isEmpty()) { System.out.println("(sin socios)"); }
                        else lista.forEach(System.out::println);
                    }
                    case 7 -> {
                        System.out.println("-- Calcular cuota --");
                        String dni = leerTexto("DNI: ").trim();
                        double cuota = srv.cuotaDe(dni);
                        System.out.printf(Locale.US, "Cuota del socio %s: $%.2f%n", dni, cuota);
                    }
                    case 8 -> {
                        System.out.println("-- Altas por mes --");
                        int[] arr = srv.getAltasPorMes();
                        String[] meses = {"Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"};
                        for(int i=0;i<12;i++) System.out.println(meses[i]+": "+arr[i]);
                    }
                    case 9 -> {
                        System.out.println("-- Bitácora --");
                        if(srv.getLog().size()==0){ System.out.println("(vacía)"); }
                        else srv.getLog().forEach(System.out::println);
                    }
                    case 0 -> System.out.println("Saliendo... ¡Éxitos!");
                    default -> System.out.println("Opción inválida.");
                }
            } catch (SocioNoEncontradoException | IllegalArgumentException e){
                System.out.println("ERROR: "+e.getMessage());
            } catch (Exception e){
                System.out.println("ERROR inesperado: "+e.getMessage());
            }
        } while(op != 0);
    }
}
